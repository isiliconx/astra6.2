from acoustic import *
from acquire import PIN
import json
def main():
 rows=json.loads((ROOT/'sources.json').read_text())['sources'];X=[];Y=[];meta=[]
 for row in rows:
  y=read(ROOT/'raw'/(row['sha']+'.wav')); z,m=measure(y,row); X.append(inputs(row));Y.append(z);meta.append(m)
 X,Y=np.array(X),np.array(Y)
 np.savez_compressed(ROOT/'features.npz',X=X,Y=Y)
 (ROOT/'measurements.json').write_text(json.dumps(meta,indent=1)+'\n')
 # Entire written root note held out, across all takes, layers and articulations. Predetermined pitches.
 hold=np.isin(X[:,0],[58,77]); prep=fit(X[~hold],Y[~hold]); prediction=predict(prep,X[hold])
 def scores(e):
  return dict(onset_harmonic_mae_db=round(float(np.mean(abs(e[:,:H]))),3),body_harmonic_mae_db=round(float(np.mean(abs(e[:,H:2*H]))),3),body_level_mae_db=round(float(np.mean(abs(e[:,2*H]))),3),attack_log_mae=round(float(np.mean(abs(e[:,2*H+1]))),3),release_log_mae=round(float(np.mean(abs(e[:,2*H+2]))),3))
 def baseline(xt,yt,xv):
  # Two transparent baselines: same articulation overall median; nearest raw note at same velocity/layer.
  byart=[];near=[]
  for x in xv:
   a=xt[:,2]==x[2];byart.append(np.median(yt[a],axis=0))
   a=a&(xt[:,1]==x[1]); dist=abs(xt[:,0]-x[0]);d=min(dist[a]);near.append(np.median(yt[a&(dist==d)],axis=0))
  return np.array(byart),np.array(near)
 by,near=baseline(X[~hold],Y[~hold],X[hold])
 # A leave-one-root-out sweep reports all roots, not lucky or cherry-picked samples.
 preds=np.zeros_like(Y);bp=np.zeros_like(Y);bn=np.zeros_like(Y)
 for p in np.unique(X[:,0]):
  ix=X[:,0]==p;preds[ix]=predict(fit(X[~ix],Y[~ix]),X[ix]);bp[ix],bn[ix]=baseline(X[~ix],Y[~ix],X[ix])
 def transfer(mask,P):
  # Carrier-relative evaluation: after fitting with none of this pitch's takes, use its
  # recorded medium spectrum as the synthesis carrier (unchanged for the no-model baseline).
  ee=[]; ee0=[]
  idx=np.flatnonzero(mask)
  for local,ix in enumerate(idx):
   if X[ix,1]==.5:continue
   anchors=(X[idx,0]==X[ix,0])&(X[idx,2]==X[ix,2])&(X[idx,1]==.5)
   if not np.any(anchors):continue
   target=Y[ix]-np.median(Y[idx[anchors]],axis=0); pred=P[local]-np.median(P[anchors],axis=0)
   ee.append(pred-target);ee0.append(-target)
  return dict(n=len(ee),model=scores(np.asarray(ee)),medium_carrier_alone=scores(np.asarray(ee0)))
 metrics=dict(heldout_pressure_transfer=transfer(hold,prediction),crossvalidated_pressure_transfer=transfer(np.ones(len(X),dtype=bool),preds),tree=PIN,takes=len(rows),sustained=int((X[:,2]==0).sum()),staccato=int((X[:,2]==1).sum()),layers=3,
    heldout=dict(roots=[58,77],train=int(sum(~hold)),test=int(sum(hold)),model=scores(prediction-Y[hold]),articulation_median=scores(by-Y[hold]),nearest_root_same_layer=scores(near-Y[hold])),
    leave_one_sounding_root_out=dict(folds=len(np.unique(X[:,0])),model=scores(preds-Y),articulation_median=scores(bp-Y),nearest_root_same_layer=scores(bn-Y)),
    model='nonlinear multi-output acoustic kernel ridge regressor',responses=['onset eight relative harmonic energies, dB','body eight relative harmonic energies, dB','body level dBFS','log attack seconds','log release seconds'])
 print(json.dumps(metrics,indent=2),flush=True)
 (ROOT/'validation.json').write_text(json.dumps(metrics,indent=1)+'\n')
 # Refit after grouped evaluation for the recording, retaining every verified source.
 xt,alpha,mean=fit(X,Y);np.savez_compressed(ROOT/'reed-weights.npz',train=xt,alpha=alpha,mean=mean)
if __name__=='__main__':main()
