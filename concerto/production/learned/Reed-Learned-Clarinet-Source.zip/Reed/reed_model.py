"""The Other Shore's hybrid clarinet. Real medium-attack carriers + learned acoustics.
render(pitch, seconds, dynamics, articulation='normal', seed=0, sr=32000, learned=True).
Dynamics is a continuous 0..1 *layer* control, not MIDI velocity; concert MIDI pitch.
Returns phase-coherent float32 mono with exactly round(seconds*sr) samples; the release is inside.
"""
from acoustic import *
from functools import lru_cache
import json
from math import gcd

def load():return Reed()

@lru_cache(maxsize=4096)
def _minimumphase(pitch,sr,deltas):
 # Real cepstral spectral factorization. Magnitudes are anchored to harmonics,
 # with smooth interpolation in log frequency. Keep natural unvoiced noise floor.
 nfft=2048;f=hz(pitch); cut=np.arange(1,9)*f
 anchor=np.r_[0,f*.56,cut,f*10.,max(f*11.,sr/2.)]; val=np.r_[0,0,deltas,deltas[-1]*.5,0]
 ff=np.fft.rfftfreq(nfft,1/sr)
 ld=np.interp(np.log1p(ff),np.log1p(anchor),val)*np.log(10)/20
 c=np.fft.irfft(ld); ca=np.zeros(nfft);ca[0]=c[0];ca[1:nfft//2]=2*c[1:nfft//2];ca[nfft//2]=c[nfft//2]
 h=np.fft.irfft(np.exp(np.fft.rfft(ca)))[:min(640,int(sr*.016))].copy()
 h[-32:]*=np.linspace(1,0,32);return h.astype('f')
class Reed:
 def __init__(self):
  z=np.load(ROOT/'reed-weights.npz');self.params=tuple(z[k] for k in ('train','alpha','mean'))
  self.desc=json.loads((ROOT/'carrier-index.json').read_text());z=np.load(ROOT/'reed-carriers.npz')
  self.bank={k:(z[k].astype('f')/32767) for k in z.files};self.candidates={s:[r for r in self.desc if r['short']==s] for s in (0,1)}
  self.call_count=0;self.learned_count=0
 @lru_cache(maxsize=4096)
 def _predict(self,p,d,s):
  return predict(self.params,[[p,d,s]])[0]
 def render(self,pitch,seconds,dynamics,articulation='normal',seed=0,sr=32000,learned=True):
  sr=int(sr);n=max(0,round(seconds*sr));art=str(articulation).lower()
  if not n:return np.zeros(0,'f')
  if not 12000<=sr<=96000:raise ValueError('sr must be between 12000 and 96000')
  if not np.isfinite([pitch,seconds,dynamics]).all():raise ValueError('inputs must be finite')
  self.call_count+=1;self.learned_count+=bool(learned)
  p=float(pitch);d=round(float(np.clip(dynamics,0,1)),3);s=int(art in ('short','stac','staccato')); leg=art in ('legato','slur','slurred')
  # Long "short" notes use a tongue attack and a held sustain; do not loop a released staccato.
  if seconds>.45 and s:s=0;leg=False
  candidates=self.candidates[s]; root=min(candidates,key=lambda r:abs(p-r['root']))['root']; choices=[r for r in candidates if r['root']==root]
  rng=np.random.default_rng(seed);r=choices[int(rng.integers(len(choices)))]; y=self.bank[r['key']]
  zs=self._predict(p,d,s); mid=self._predict(p,.5,s);anchor=self._predict(float(root),.5,s)
  # Relative to the exact training condition of the recorded mezzo carrier; add a small
  # absolute correction for variation between takes within a zone.
  observed=np.array(r['features']);delta=np.clip(.90*(zs[:16]-anchor[:16])+.18*(anchor[:16]-observed[:16]),-10.,10.)
  attack=np.exp(zs[-2]) if learned else .073; release=np.exp(zs[-1]) if learned else .16
  # Authored phrasing constrains growth within written rhythmic gates. Both durations
  # use the model of acoustic onset/decay instead of turning every beat into an ADSR.
  a=np.clip(attack*(.115 if leg else .63 if s else .41),.006 if leg else .012,.022 if leg else .053 if s else .080)
  rel=np.clip(release*(.18 if leg else .38 if s else .24),.009 if leg else .018,.025 if leg else .062 if s else .074)
  a=min(a,seconds*.34);rel=min(rel,seconds*.39)
  start=(r['t75']+rng.uniform(.105,.355)) if leg else (max(r['t15'],r['t75']-(.049 if s else .044))) 
  # Natural short-note pitch drift belongs in the tongue and release; align based on the core.
  step=SR/sr*hz(p)/r['f']
  source=start*SR+np.arange(n)*step
  if source[-1]>=len(y)-1 and not s:
   # Long held notes not present in the score: phase-matched wrap with a smooth splice.
   lo=int(SR*max(.69, r['t75']+.30));hi=min(len(y)-4,int(SR*max(1.45,min(4.45,r['hi']-.8))))
   if hi-lo>SR*.4:
    # Align using measured period; crossfade a few fundamental cycles.
    period=SR/r['f'];L=round((hi-lo)/period)*period
    if L>100:
     z=source.copy();mask=z>=lo+L;z[mask]=lo+(z[mask]-lo)%L
     samples=np.interp(z,np.arange(len(y)),y,right=0)
     blend=min(.10*SR,L*.10);m=z>lo+L-blend
     v=(z[m]-(lo+L-blend))/blend;w=.5-.5*np.cos(v*np.pi)
     samples[m]=(1-w)*samples[m]+w*np.interp(z[m]-L+blend,np.arange(len(y)),y)
    else:samples=np.interp(source,np.arange(len(y)),y,right=0)
   else:samples=np.interp(source,np.arange(len(y)),y,right=0)
  else:samples=np.interp(source,np.arange(len(y)),y,right=0)
  x=samples.astype('f')/r['body']
  # One phase-preserving acoustic carrier. No crossfading among out-of-phase pitch layers.
  if learned:
   def filt(dv,note):
    ints=tuple(np.rint(dv*10.)/10.);h=_minimumphase(p,sr,ints)
    return signal.oaconvolve(note,h,mode='full')[:len(note)].astype('f')
   body=filt(delta[8:],x);nc=min(n,int(sr*(.050 if leg else .110 if s else .180)))
   onset=filt(delta[:8],x[:nc]);w=(.5+.5*np.cos(np.linspace(0,np.pi,nc)))**(1.2 if s else 1.)
   body[:nc]+=(onset-body[:nc])*w; x=body
  # The underlying dynamic slope is learned. The authored seat calibration is not
  # a level-only model: acoustic spectral filters above are independent of level.
  ldb=float(np.clip(.96*(zs[-3]-mid[-3]),-14.,12.)) if learned else (d-.5)*12
  gain=.20*10**(ldb/20.)
  na=min(n,max(1,round(a*sr)));nr=min(n,max(1,round(rel*sr)))
  w=np.linspace(0,1,na,dtype='f');x[:na]*=np.sin(w*(np.pi/2))**(1.0 if leg else 1.22)
  w=np.linspace(0,1,nr,dtype='f');x[-nr:]*=np.maximum(0.,np.cos(w*(np.pi/2)))**1.45
  # Stable calibration by recorded *sounding* body, not peak-normalizing each note.
  x*=gain
  if n:x[0]=x[-1]=0
  return np.ascontiguousarray(x,dtype='f')
