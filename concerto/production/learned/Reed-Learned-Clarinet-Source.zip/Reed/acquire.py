"""Verify and acquire the 97 CC0 clarinet takes from one pinned VSCO 2 CE tree."""
from pathlib import Path
import hashlib, json, re, concurrent.futures, urllib.request, urllib.parse,time
D=Path(__file__).resolve().parent
PIN='440300901dfe9275fd84e0b7763af1f8443ae62e'
REPO='https://raw.githubusercontent.com/sgossner/VSCO-2-CE/'
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def fetch():
 if (D/'sources.json').exists():
  rows=json.loads((D/'sources.json').read_text())['sources']
 else:
  t=json.loads((D.parent.parent/'sample-tree.json').read_text())
  assert t['sha']==PIN and not t['truncated']
  rows=[]
  for x in t['tree']:
   m=re.fullmatch(r'Woodwinds/Clarinet/(stac|susLong)/DCClar_\w+_([A-G])(#?)(\d)_v([1-3])_rr([1-2])_sum.wav',x['path'])
   if not m:continue
   kind,L,acc,oct,v,rr=m.groups()
   midi=12*(2+int(oct))+'C D EF G A B'.index(L)+len(acc)
   rows.append(dict(path=x['path'],sha=x['sha'],bytes=x['size'],pitch=midi,layer=int(v),rr=int(rr),short=int(kind=='stac')))
  assert len(rows)==97
  (D/'sources.json').write_text(json.dumps(dict(repository='sgossner/VSCO-2-CE',tree=PIN,license='CC0-1.0',sources=rows),indent=1)+'\n')
 des=D/'raw'; des.mkdir(exist_ok=True)
 def one(r):
  path=des/(r['sha']+'.wav');local=D.parent.parent/'samples'/path.name
  q=path if path.exists() else local if local.exists() else None
  if q: b=q.read_bytes()
  else:
   for k in range(3):
    try: b=urllib.request.urlopen(REPO+PIN+'/'+urllib.parse.quote(r['path']),timeout=18).read();break
    except Exception:
     if k==2:raise
     time.sleep(.5+k)
  assert len(b)==r['bytes'] and blob(b)==r['sha'],r['path']
  if q!=path:path.write_bytes(b)
 with concurrent.futures.ThreadPoolExecutor(8) as e:list(e.map(one,rows))
 print(len(rows),'verified',sum(r['bytes'] for r in rows))
if __name__=='__main__':fetch()
