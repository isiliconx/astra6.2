"""Blind-pitch transfer check on *rendered audio*, and phase/gain-insensitive controls."""
from reed_model import *
from scipy.io import wavfile
import hashlib
def main():
 reed=load();rows=json.loads((ROOT/'sources.json').read_text())['sources']
 f=np.load(ROOT/'features.npz');X,Y=f['X'],f['Y']; hold=np.isin(X[:,0],[58,77])
 reed.params=fit(X[~hold],Y[~hold]);reed._predict.cache_clear()
 errors=[];e0=[];ef=[];audio_scores=[]
 for i in np.flatnonzero(hold & (X[:,1]!=.5)):
  p,d,s=X[i];art='short' if s else 'normal';seed=rows[i]['rr'];dur=.20 if s else .80
  # The model never saw this pitch during fitting. Give both synthesis paths the same
  # real medium carrier at inference. Ground truth is soft/loud-minus-medium natural spectrum.
  med=hold&(X[:,0]==p)&(X[:,1]==.5)&(X[:,2]==s)
  target=Y[i,H:2*H]-np.median(Y[med,H:2*H],axis=0)
  spectra=[]
  for learnt,dd in [(True,d),(True,.5),(False,d),(False,.5)]:
   wave=reed.render(p,dur,dd,art,seed=seed,learned=learnt)
   assert len(wave)==round(dur*SR) and np.isfinite(wave).all() and wave[0]==wave[-1]==0
   spans=[(.045,.105),(.054,.117),(.067,.127)] if s else [(.21,.37),(.36,.52),(.52,.68)]
   spectra.append(harmonic(wave,hz(p),spans))
  e=(spectra[0]-spectra[1])-target;b=(spectra[2]-spectra[3])-target
  errors.extend(e);e0.extend(b)
  audio_scores.append(dict(root=int(p),art=art,layer=int(rows[i]['layer']),rr=seed,modeled_body_harmonic_delta_mae_db=round(float(np.mean(abs(e))),3),fixed_carrier_body_harmonic_delta_mae_db=round(float(np.mean(abs(b))),3)))
 rendermetrics=dict(heldout_roots=[58,77],heldout_takes=18,soft_loud_targets=len(audio_scores),
  mode='fixed acoustic analysis windows on actual synthesized, amplitude-normalized harmonic spectra; soft/loud minus medium; averaged over eight harmonics',model_db=round(float(np.mean(np.abs(errors))),3),fixed_carrier_db=round(float(np.mean(np.abs(e0))),3),per_take=audio_scores)
 reed=load();probe=[];ac=[];single=[]
 # Same notes/rhythm/seed for all takes. RMS-level-matched spectral difference is not ornamental gain.
 events=[(58,.94,.18,'normal'),(65,.51,.34,'legato'),(69,.49,.5,'legato'),(74,.80,.76,'normal'),(77,.22,.88,'short'),(75,.22,.70,'short'),(73,.22,.59,'short'),(71,1.15,.36,'legato'),(67,.67,.22,'normal')]
 for b in (True,False):
  ary=[]
  for j,(p,d,pressure,art) in enumerate(events):
   y=reed.render(p,d,pressure,art,j,learned=b); ary.extend([y,np.zeros(100 if art=='legato' else 850,'f')])
   if b:
    ref=reed.render(p,d,pressure,art,j,learned=False)
    # Remove the best-fitting scalar gain; residual is time and/or timbre, never pure loudness.
    gain=float(y@ref/(np.dot(ref,ref)+1e-12));diff=float(np.linalg.norm(y-gain*ref)/(np.linalg.norm(y)+1e-12));single.append(round(diff,4))
  wave=np.concatenate(ary)
  wavfile.write(ROOT/('probe-learned.wav' if b else 'probe-sample-control.wav'),SR,(np.clip(wave,-1,1)*32767).astype('int16'))
  probe.append(dict(mode='learned' if b else 'sample-only control',seconds=round(len(wave)/SR,3),rms=round(float(np.sqrt(np.mean(wave**2))),4),peak=round(float(np.max(abs(wave))),4)))
 checks=[]
 for p in [49,53,58,62,71,77,83,90]:
  for d in [0,.5,1.]:
   for art in ['normal','legato','short']:
    for sr,dur in [(32000,.14),(44100,.72),(32000,7.0)]:
     w=reed.render(p,dur,d,art,17,sr=sr);assert w.dtype==np.float32 and len(w)==round(dur*sr) and np.isfinite(w).all() and w[0]==0 and w[-1]==0
     if d==.5 and sr==44100 and art!='short':checks.append(np.sqrt(np.mean(w**2)))
 out=dict(blind_rendered_audio=rendermetrics,probes=probe,ablation_residual_relative_rms_per_note=single,median_residual=round(float(np.median(single)),4),endpoint_rate_and_length_checks=216,mean_tested_mezzo_rms_720ms_sustains=round(float(np.mean(checks)),4),weights_sha256=hashlib.sha256((ROOT/'reed-weights.npz').read_bytes()).hexdigest())
 (ROOT/'inference-verification.json').write_text(json.dumps(out,indent=1)+'\n');print(json.dumps(out,indent=2))
if __name__=='__main__':main()
