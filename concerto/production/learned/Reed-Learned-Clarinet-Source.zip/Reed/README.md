# Reed / The Other Shore

Reed gives the concerto's **solo** a learned dynamic timbre. It is a small supervised acoustic model coupled to recordings, not an end-to-end audio generator, automatic composer, generic MIDI synth, or a neural network. In the concert recording, the musical notes, rhythms, and phrasing come from the authored score.

## Play a note

NumPy and SciPy are the only nonstandard dependencies (tested with 2.3.5 and 1.17.0). No network, GPU, external app, proprietary model, or training run is needed for inference. From this directory:

```python
from scipy.io import wavfile
from reed_model import load
reed = load()
x = reed.render(69, 1.2, 0.60, articulation="legato", seed=731, sr=32000)
wavfile.write("concert-A.wav", 32000, x)
```

The `render(pitch, seconds, dynamics, articulation="normal", seed=0, sr=32000, learned=True)` API takes **sounding concert MIDI pitch**, duration in seconds, and a 0–1 pressure control (the middle equals a mezzo recording, not MIDI velocity 64). It returns contiguous mono float32, exactly `round(seconds*sr)` frames, first and last samples zero, with the release inside that duration. Normal, legato, and short are distinct. Specify a slight overlap across slurred notes in your score scheduler if desired. Default output is 32 kHz; accepted range 12–96 kHz. Sustained mezzo averages about 0.21 RMS in the tested 720 ms notes. Float peaks can exceed 1 in very loud attacks; use an instrument bus with headroom, do not clip individual notes. A fixed seed reproduces the same round robin and legato offset.

## What is learned

- A multi-output nonlinear kernel ridge regression maps sounding MIDI pitch, continuous dynamic layer, and sustained/tongued articulation to **19 acoustic descriptors**: eight onset harmonic energies, eight body harmonic energies, recorded body level, and log attack/release durations. Harmonic levels are measured relative to energy in harmonics 1–8, not absolute volume. The three recorded velocity layers are a proxy for playing intensity, not a physically measured reed pressure.
- A phase-preserving minimum-phase filter modifies a real medium carrier from the same library using predicted spectral changes. A different filter is used at the start than in the body. The tonal pressure slope and bounded attack/release timing are applied on each note, while characteristic waveform detail and breath noise remain recorded. There is no mixing of two asynchronous dynamic-layer waveforms.
- Written articulation, note durations, slur envelopes, round-robin policy, filter gain limits, seat calibration, and room/mix are **designed**, not learned. A legato note starts inside an actual held tone; no recorded note-to-note legato transition dataset was available. No claim of a modeled embouchure, physical instrument bore or listener preference.

## Evidence

97 hash-verified CC0 source recordings (33 sustained; 64 short; three layers, two short round robins), 11 distinct sounding sample roots. All three highest sustained samples are labeled F-sharp but their measured fundamental is F; the bank and split use the sounding root.

The 18 B-flat3/F5 recordings were held out together across all articulations and layers. Fit on the other 79, then compare models' ability to reproduce the *change* between medium and soft/loud. Both get the same held-out medium recordings at synthesis time; neither gets target soft/loud audio. Root audio is never split into near-identical training/test frames.

| Test | Medium carrier alone | Learned acoustic model |
| --- | ---: | ---: |
| Two-root holdout: actual rendered waveform, eight-harmonic body-change MAE, 12 target recordings | 5.90 dB | 3.67 dB |
| All 11 leave-one-root-out folds: predicted onset-change MAE, 64 targets | 6.89 dB | 5.18 dB |
| All folds: predicted body-change MAE | 5.93 dB | 4.35 dB |
| All folds: predicted body-level-change MAE | 4.82 dB | 2.15 dB |

This specifically supports **learning the change of timbre and level with dynamics**, not modeling all aspects of the instrument better than a nearest-note sampler. The nearest same-layer sample baseline was stronger on some absolute spectrum tests; pure note-to-note attack/release extrapolation did not reliably beat the simple baseline. Timing outputs are therefore bounded. It is one instrument library and not a listening panel or a human-performance equivalence claim. Full component-level and per-take results are in `validation.json` and `inference-verification.json`.

`probe-learned.wav` and `probe-sample-control.wav` are the same unaccompanied 5.39-second phrase, same notes and seeds. The ablation bypasses the learned spectral filters, learned level and learned timing. Mean phrase RMS is comparable (0.198 vs 0.202); the median per-note sound difference after removing the best-fit scalar gain is 22.3% relative RMS. The verification also covers 216 sample rate, duration, endpoint and finite-value checks.

## Reproduce

- Source: [Versilian Studios Chamber Orchestra 2 Community Edition](https://github.com/sgossner/VSCO-2-CE/tree/440300901dfe9275fd84e0b7763af1f8443ae62e). This package's carrier recordings derive from the project’s **CC0** clarinet samples. Full upstream dedication included in `VSCO-LICENSE.txt`.
- `sources.json` pins every upstream path, byte count and Git blob SHA-1. `python acquire.py` verifies cached files and retrieves only missing original clarinet takes from that pinned GitHub tree. `raw/` is intentionally not needed for normal playback. `python train.py` reextracts features, runs evaluation and refits the production weights on all 97 takes. Then run `python bank.py` and `python verify_model.py`. Set `OPENBLAS_NUM_THREADS=1` for predictable CPU usage.
- Minimal offline inference files: `reed_model.py`, `acoustic.py`, `reed-weights.npz`, `reed-carriers.npz`, `carrier-index.json`, and the sample dedication. The 3.4 MB carrier file is mono PCM; the fitted weights are about 15 kB, not hidden inside the sample audio.
