"""Feature extraction and nonlinear ridge regression. NumPy / SciPy; no pretrained weights."""
import numpy as np
from scipy import signal, ndimage
from scipy.io import wavfile
from pathlib import Path
import warnings
ROOT=Path(__file__).resolve().parent
SR=32000
H=8
def hz(m):return 440*2**((m-69)/12)
def db(x):return 20*np.log10(np.maximum(x,1.e-10))
def read(path):
 with warnings.catch_warnings():
  warnings.simplefilter('ignore',wavfile.WavFileWarning); sr,x=wavfile.read(path)
 scale=2**(np.iinfo(x.dtype).bits-1) if x.dtype.kind=='i' else 1.
 y=x.astype('f')/scale
 if y.ndim>1:y=y.mean(axis=1)
 from math import gcd
 g=gcd(SR,sr); return signal.resample_poly(y,SR//g,sr//gcd(SR,sr)).astype('f')
def smoothenv(y):
 # 6 ms moving RMS and median smoothing suppress spurious crossing by wind/key noise.
 w=max(4,int(SR*.006)); hop=64
 e=np.sqrt(np.maximum(ndimage.uniform_filter1d((y*y).astype('d'),w,mode='nearest')[::hop],1e-12))
 return ndimage.median_filter(e,5),hop
def measured_pitch(y,nominal):
 n=len(y); nfft=2**int(np.ceil(np.log2(max(8192,2*n))))
 s=np.abs(np.fft.rfft(y*np.hanning(n),n=nfft))
 f=hz(nominal); k0=max(1,int(nfft*f*.93/SR));k1=int(nfft*f*1.055/SR)+1
 # Root is sometimes weak in chalumeau notes. Average evidence from 5 harmonics.
 ks=np.linspace(k0,k1,max(4,(k1-k0)*7));fx=np.arange(len(s))
 vote=0.
 for h in (1,2,3,4,5):
  a=np.interp(ks*h,fx,s); vote=vote+np.log1p(30*a/(max(a.max(),1e-9)))/np.sqrt(h)
 return ks[np.argmax(vote)]*SR/nfft
def harmonic(y,f,limits):
 # Window-local harmonic power measurements; do not rely on frame-to-frame phase.
 ls=[]
 for a,b in limits:
  a,b=round(a*SR),min(len(y),round(b*SR)); z=y[max(0,a):b]; n=len(z)
  if n<120:continue
  nfft=2**int(np.ceil(np.log2(max(8192,n))))
  power=abs(np.fft.rfft(z*np.hanning(n),n=nfft))**2
  freqs=np.fft.rfftfreq(nfft,1/SR);v=[]
  for h in range(1,H+1):
   bw=max(1.7*SR/n,min(f*.19,f*.014*h))
   i=np.abs(freqs-h*f)<bw; v.append(power[i].sum())
  vals=np.array(v);ls.append(np.maximum(-52.,10*np.log10((vals+1.e-20)/(vals.sum()+1.e-20))))
 return np.median(ls,axis=0)
def measure(y,row):
 env,hop=smoothenv(y); ts=np.arange(len(env))*hop/SR;short=row['short'];nom=row['pitch']
 body=np.quantile(env[env>np.quantile(env,.985)*.34],.66) if short else np.quantile(env,.60)
 active=env>body*.08;ix=np.flatnonzero(active); lo=ts[ix[0]];hi=ts[ix[-1]]
 # Locate the note's primary attack; quiet file lead and key clicks don't define it.
 first=lambda threshold:ts[np.flatnonzero(env>threshold*body)[0]]
 last=lambda threshold:ts[np.flatnonzero(env>threshold*body)[-1]]
 t15,t35,t75=map(first,[.15,.35,.75]); t65=first(.65)
 last75,last15=map(last,[.75,.15]); at=np.clip(t75-t15,.008,.55);rel=np.clip(last15-last75,.015,.70)
 attackq=t35; bodyq=float(np.median(ts[env>=body*.94])) if short else lo+min(hi*.28,1.2)
 w=.055 if short else .14
 mid0=max(0,bodyq-w*.5); mid1=mid0+w
 f=measured_pitch(y[round(SR*mid0):round(SR*mid1)],nom)
 # Estimate attacks near 35% and 65% of the body amplitude, then body spectra over three frames.
 wa=.032 if short else .055
 onset=harmonic(y,f,[(max(0,t-wa*.30),max(0,t-wa*.30)+wa) for t in (t35,t65)])
 bc=[bodyq-.012,bodyq,bodyq+.016] if short else [bodyq,min(hi*.52,bodyq+1.1),min(hi*.73,bodyq+2.15)]
 spec=harmonic(y,f,[(max(0,t-w*.5),max(0,t-w*.5)+w) for t in bc])
 Y=np.r_[onset,spec,db(body),np.log(at),np.log(rel)]
 meta=dict(f=float(f),body=float(body),attack=float(at),rel=float(rel),t15=float(t15),t35=float(t35),t75=float(t75),hi=float(hi),bodyq=float(bodyq),nominal=nom)
 return Y,meta
def physical_root(row):
 # All three F#5-labelled sustains sound F5; checked against the measured fundamental.
 return 89 if row['short']==0 and row['pitch']==90 else row['pitch']
def inputs(row):return [physical_root(row),(row['layer']-1)*.5,row['short']]
def kernel(A,B):
 A,B=np.atleast_2d(A),np.atleast_2d(B)
 p=(A[:,0,None]-B[None,:,0]); d=(A[:,1,None]-B[None,:,1]); same=(A[:,2,None]==B[None,:,2]).astype(float)
 # Additive-plus-interaction kernel: broad physics across articulations, plus separate local behavior.
 kp=np.exp(-.5*(p/6.0)**2); smooth=np.exp(-.5*(p/14.)**2); kd=np.exp(-.5*(d/.61)**2)
 return 1.+.33*same+1.6*kp+.7*kd+.35*same*kd+.7*same*kp+.75*kp*kd+.30*kp*kd*same+.4*smooth*kd
def fit(X,Y):
 mean=Y.mean(axis=0);alpha=np.linalg.solve(kernel(X,X)+.16*np.eye(len(X)),Y-mean)
 return X,alpha,mean
def predict(params,X):
 train,alpha,mean=params;return kernel(X,train)@alpha+mean
