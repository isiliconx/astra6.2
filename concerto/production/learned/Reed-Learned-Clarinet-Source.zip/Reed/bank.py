"""Make the redistributable, phase-coherent PCM carrier bank from verified CC0 WAVs."""
from acoustic import *
import json
def main():
 rows=json.loads((ROOT/'sources.json').read_text())['sources']; measurements=json.loads((ROOT/'measurements.json').read_text()); feats=np.load(ROOT/'features.npz')['Y']
 bank={};desc=[]
 for row,meta,z in zip(rows,measurements,feats):
  if row['layer']!=2:continue
  y=read(ROOT/'raw'/(row['sha']+'.wav'))
  # Leave the actual room/breath intact; four seconds (when available) covers every written held note.
  key='s'+str(len(desc));y=y[:round(SR*(min(5.2,max(meta['hi']-.23,.7)) if not row['short'] else min(.68,meta['hi']+.07)))]
  bank[key]=np.rint(np.clip(y,-.99996,.99996)*32767).astype(np.int16)
  desc.append(dict(key=key,root=physical_root(row),rr=row['rr'],short=row['short'],sha=row['sha'],**meta,features=z.round(6).tolist()))
 np.savez_compressed(ROOT/'reed-carriers.npz',**bank)
 (ROOT/'carrier-index.json').write_text(json.dumps(desc,separators=(',',':'))+'\n')
if __name__=='__main__':main()
