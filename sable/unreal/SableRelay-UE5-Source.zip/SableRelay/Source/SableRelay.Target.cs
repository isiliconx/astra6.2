using UnrealBuildTool;

public class SableRelayTarget : TargetRules
{
    public SableRelayTarget(TargetInfo Target) : base(Target)
    {
        Type = TargetType.Game;
        DefaultBuildSettings = BuildSettingsVersion.V5;
        IncludeOrderVersion = EngineIncludeOrderVersion.Unreal5_5;
        ExtraModuleNames.Add("SableRelay");
    }
}
